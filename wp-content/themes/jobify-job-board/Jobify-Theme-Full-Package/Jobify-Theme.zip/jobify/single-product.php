<?php
/**
 * Single Product
 */

locate_template( array( 'archive-product.php' ), true );